#ifndef MATRIXLIB_MATRIXLIB_H
#define MATRIXLIB_MATRIXLIB_H

///////////////////////////////////// int

int** addMatrix(int** A, int** B, int m, int n){
    int** result = new int*[m];
    for(int i = 0; i<m; ++i){
        result[i] = new int[n];
        for(int j = 0; j<n; ++j){
            result[i][j] = A[i][j] + B[i][j];
        }
    }

    return result;
}

int** subtractMatrix(int** A, int** B, int m, int n){
    int** result = new int*[m];
    for(int i = 0; i<m; ++i){
        result[i] = new int[n];
        for(int j = 0; j<n; ++j){
            result[i][j] = A[i][j] - B[i][j];
        }
    }

    return result;
}

int** multiplyMatrix(int** A, int** B, int m, int n, int k){
    int** result = new int*[m];
    for(int i = 0; i<m; ++i){
        result[i] = new int[k];
    }

    for(int i = 0; i < m; ++i){
        for(int j = 0; j<k; ++j){
            result[i][j] = 0;
            for(int p = 0; p<n; ++p){
                result[i][j] += A[i][p]*B[p][j];
            }
        }
    }

    return result;
}

int** multiplyByScalar(int** A, int m, int n, int scalar){
    int** result = new int*[m];
    for(int i = 0; i<m; ++i){
        result[i] = new int[n];
        for(int j = 0; j<n; ++j){
            result[i][j] = A[i][j]*scalar;
        }
    }

    return result;
}

int** transpozeMatrix(int** A, int m, int n){
    int** result = new int*[n];
    for(int i = 0; i<n; ++i){
        result[i] = new int[m];
    }

    for(int i = 0; i<m; ++i){
        for(int j = 0; j<n; ++j){
            result[j][i] = A[i][j];
        }
    }

    return result;
}

int** powerMatrix(int** A, int m, int n, unsigned pow){
    int** result;
    result = new int*[m];
    for(int i = 0; i<m; ++i) {
        result[i] = new int[n];
        for (int j = 0; j < n; ++j) {
            result[i][j] = A[i][j];
        }
    }
    for(int i = 1; i<pow; ++i) {
        int** tmp = multiplyMatrix(result, A, m, n, n);
        for(int j = 0; j<m; ++j) {
            for (int k = 0; k < n; ++k) {
                result[j][k] = tmp[j][k];
            }
            delete[] tmp[j];
        }
        delete[] tmp;
    }

    return result;
}

void detDetail(int **A, int **tmp, int p,
                 int q, int n)
{
    int i = 0, j = 0;
    for (int row = 0; row < n; ++row)
    {
        for (int col = 0; col < n; ++col)
        {
            if (row != p && col != q)
            {
                tmp[i][j++] = A[row][col];
                if (j == n - 1)
                {
                    j = 0;
                    ++i;
                }
            }
        }
    }
}

int determinantOfMatrix(int **A, int m, int n)
{
    int result = 0;
    if (n == 1)
        return A[0][0];

    int **tmp = new int*[m];
    for(int i = 0; i<m; ++i)
        tmp[i] = new int[m];

    int sign = 1;

    for (int i = 0; i < n; ++i)
    {
        detDetail(A, tmp, 0, i, n);
        result += sign * A[0][i] * determinantOfMatrix(tmp, m, n - 1);

        sign = -sign;
    }

    return result;
}

bool matrixIsDiagonal(int** A, int m, int n){
    if(m!=n) return false;

    for(int i = 0; i<m; ++i){
        if(A[i][i] != 1) return false;
        for(int j = 0; j<n; ++j)
        {
            if(i!=j && A[i][j] != 0) return false;
        }
    }

    return true;
}

void swap(int& a, int& b){
    int tmp = a;
    a = b;
    b = tmp;
}

void sortRow(int* row, int n){
    for(int i = 0; i<n; ++i){
        for(int j = 0; j<n-i-1; ++j){
            if(row[j] > row [j+1]) swap(row[j], row[j+1]);
        }
    }
}

void sortRowsInMatrix(int** A, int m, int n){
    for(int i = 0; i<m; ++i){
        sortRow(A[i], n);
    }
}

//////////////////////////// double

double** addMatrix(double** A, double** B, int m, int n){
    double** result = new double*[m];
    for(int i = 0; i<m; ++i){
        result[i] = new double[n];
        for(int j = 0; j<n; ++j){
            result[i][j] = A[i][j] + B[i][j];
        }
    }

    return result;
}

double** subtractMatrix(double** A, double** B, int m, int n){
    double** result = new double*[m];
    for(int i = 0; i<m; ++i){
        result[i] = new double[n];
        for(int j = 0; j<n; ++j){
            result[i][j] = A[i][j] - B[i][j];
        }
    }

    return result;
}

double** multiplyMatrix(double** A, double** B, int m, int n, int k){
    double** result = new double*[m];
    for(int i = 0; i<m; ++i){
        result[i] = new double[k];
    }

    for(int i = 0; i < m; ++i){
        for(int j = 0; j<k; ++j){
            result[i][j] = 0;
            for(int p = 0; p<n; ++p){
                result[i][j] += A[i][p]*B[p][j];
            }
        }
    }

    return result;
}

double** multiplyByScalar(double** A, int m, int n, double scalar){
    double** result = new double*[m];
    for(int i = 0; i<m; ++i){
        result[i] = new double[n];
        for(int j = 0; j<n; ++j){
            result[i][j] = A[i][j]*scalar;
        }
    }

    return result;
}

double** transpozeMatrix(double** A, int m, int n){
    double** result = new double*[n];
    for(int i = 0; i<n; ++i){
        result[i] = new double[m];
    }

    for(int i = 0; i<m; ++i){
        for(int j = 0; j<n; ++j){
            result[j][i] = A[i][j];
        }
    }

    return result;
}

double** powerMatrix(double** A, int m, int n, unsigned pow){
    double** result;
    result = new double*[m];
    for(int i = 0; i<m; ++i) {
        result[i] = new double[n];
        for (int j = 0; j < n; ++j) {
            result[i][j] = A[i][j];
        }
    }
    for(int i = 1; i<pow; ++i) {
        double** tmp = multiplyMatrix(result, A, m, n, n);
        for(int j = 0; j<m; ++j) {
            for (int k = 0; k < n; ++k) {
                result[j][k] = tmp[j][k];
            }
            delete[] tmp[j];
        }
        delete[] tmp;
    }

    return result;
}

void detDetail(double **A, double **tmp, int p,
               int q, int n)
{
    int i = 0, j = 0;
    for (int row = 0; row < n; ++row)
    {
        for (int col = 0; col < n; ++col)
        {
            if (row != p && col != q)
            {
                tmp[i][j++] = A[row][col];
                if (j == n - 1)
                {
                    j = 0;
                    ++i;
                }
            }
        }
    }
}

double determinantOfMatrix(double **A, int m, int n)
{
    double result = 0;
    if (n == 1)
        return A[0][0];

    double **tmp = new double*[m];
    for(int i = 0; i<m; ++i)
        tmp[i] = new double[m];

    int sign = 1;

    for (int i = 0; i < n; ++i)
    {
        detDetail(A, tmp, 0, i, n);
        result += sign * A[0][i] * determinantOfMatrix(tmp, m, n - 1);

        sign = -sign;
    }

    return result;
}

bool matrixIsDiagonal(double** A, int m, int n){
    if(m!=n) return false;

    for(int i = 0; i<m; ++i){
        for(int j = 0; j<n; ++j)
        {
            if(i!=j && A[i][j] != 0) return false;
        }
    }

    return true;
}

void swap(double& a, double& b){
    int tmp = a;
    a = b;
    b = tmp;
}

void sortRow(double* row, int n){
    for(int i = 0; i<n; ++i){
        for(int j = 0; j<n-i-1; ++j){
            if(row[j] > row [j+1]) swap(row[j], row[j+1]);
        }
    }
}

void sortRowsInMatrix(double** A, int m, int n){
    for(int i = 0; i<m; ++i){
        sortRow(A[i], n);
    }
}

#endif //MATRIXLIB_MATRIXLIB_H

#include <iostream>
#include "matrixLib.h"
#include <string.h>

void printMatrix(double **Matrix, int m, int n){
    for(int i = 0; i < m; ++i){
        for(int j = 0; j<n; ++j){
            std::cout << Matrix[i][j] << '\t';
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

void displayHelp(){
    std::cout << R"(HELP:

add - for add matrices
sub - for subtract matrices
mul - for matrix multiplication
scalar - for matrix multiplication by a scalar
tr - to transpose matrices
pow - for exponentiation of matrices
det - to find the determinant
diag - to check for diagonality
srow - to sort the string
sort - to sort the matrix

)";
}

double **enterMatrix(const std::string& name, int m, int n){
    double** result = new double*[m];
    for(int i = 0; i<m; ++i) result[i] = new double[n];

    for(int i = 0; i<m; ++i){
        for(int j = 0; j<n; ++j){
            std::cout << "Enter " + name + "[" << i << "]["<< j << "]: ";
            std::cin >> result[i][j];
        }
    }

    return result;
}

int main(int argc, char* argv[]) {
    int m1, n1, n2;
    double scalar;
    unsigned power;
    double** A;
    double** B;

    if (argc != 2) {
        displayHelp();
    }


    else if (strcmp(argv[1], "add") == 0) {
        std::cout << "A + B" << std::endl;
        std::cout << "Enter number of rows: ";
        std::cin >> m1;
        std::cout << "Enter number of columns: ";
        std::cin >> n1;

        A = enterMatrix("A", m1, n1);
        B = enterMatrix("B", m1, n1);
        double **A_plus_B = addMatrix(A, B, m1, n1);
        std::cout << "\nresult:\n\n";
        printMatrix(A_plus_B, m1, n1);
    } else if (strcmp(argv[1], "sub") == 0) {
        std::cout << "A - B" << std::endl;
        std::cout << "Enter number of rows: ";
        std::cin >> m1;
        std::cout << "Enter number of columns: ";
        std::cin >> n1;

        A = enterMatrix("A", m1, n1);
        B = enterMatrix("B", m1, n1);
        double **A_minus_B = subtractMatrix(A, B, m1, n1);
        std::cout << "\nresult:\n\n";
        printMatrix(A_minus_B, m1, n1);
    } else if (strcmp(argv[1], "mul") == 0) {
        std::cout << "A * B" << std::endl;
        std::cout << "Enter number of rows for first matrix: ";
        std::cin >> m1;
        std::cout << "Enter number of columns for first matrix: ";
        std::cin >> n1;
        std::cout << "Enter number of columns for second matrix: ";
        std::cin >> n2;
        A = enterMatrix("A", m1, n1);
        B = enterMatrix("B", n1, n2);
        double **A_mul_B = multiplyMatrix(A, B, m1, n1, n2);
        std::cout << "\nresult:\n\n";
        printMatrix(A_mul_B, m1, n2);
    } else if (strcmp(argv[1], "scalar") == 0) {
        std::cout << "scalar*A" << std::endl;
        std::cout << "Enter number of rows: ";
        std::cin >> m1;
        std::cout << "Enter number of columns: ";
        std::cin >> n1;
        A = enterMatrix("A", m1, n1);
        std::cout << "Enter scalar: ";
        std::cin >> scalar;
        double **scalarA = multiplyByScalar(A, m1, n1, scalar);
        std::cout << "\nresult:\n\n";
        printMatrix(scalarA, m1, n1);
    } else if (strcmp(argv[1], "tr") == 0) {
        std::cout << "tr(A)" << std::endl;
        std::cout << "Enter number of rows: ";
        std::cin >> m1;
        std::cout << "Enter number of columns: ";
        std::cin >> n1;
        A = enterMatrix("A", m1, n1);
        double **trA = transpozeMatrix(A, m1, n1);
        std::cout << "\nresult:\n\n";
        printMatrix(trA, n1, m1);
    } else if (strcmp(argv[1], "pow") == 0) {
        std::cout << "A^power" << std::endl;
        std::cout << "Enter number of rows: ";
        std::cin >> m1;
        std::cout << "Enter number of columns: ";
        std::cin >> n1;
        A = enterMatrix("A", m1, n1);
        std::cout << "Enter power: ";
        std::cin >> power;
        double **A_in_power = powerMatrix(A, m1, n1, power);
        std::cout << "\nresult:\n\n";
        printMatrix(A_in_power, n1, m1);
    } else if (strcmp(argv[1], "det") == 0) {
        std::cout << "det(A)" << std::endl;
        std::cout << "Enter number of rows: ";
        std::cin >> m1;
        std::cout << "Enter number of columns: ";
        std::cin >> n1;
        A = enterMatrix("A", m1, n1);
        double det = determinantOfMatrix(A, m1, n1);
        std::cout << "\nresult:\n\n";
        std::cout << det << std::endl;
    } else if (strcmp(argv[1], "diag") == 0) {
        std::cout << "isDiagonal(A)" << std::endl;
        std::cout << "Enter number of rows: ";
        std::cin >> m1;
        std::cout << "Enter number of columns: ";
        std::cin >> n1;
        A = enterMatrix("A", m1, n1);
        bool result = matrixIsDiagonal(A, m1, n1);
        std::cout << "\nresult:\n\n";
        std::cout << std::boolalpha << result << std::endl;
    } else if (strcmp(argv[1], "srow") == 0) {
        std::cout << "sortRow of matrix A" << std::endl;
        std::cout << "Enter number of rows: ";
        std::cin >> m1;
        std::cout << "Enter number of columns: ";
        std::cin >> n1;
        A = enterMatrix("A", m1, n1);
        int row;
        std::cout << "Matrix: \n";
        printMatrix(A, m1, n1);
        std::cout << "Enter row of matrix to sort: ";
        std::cin >> row;
        sortRow(A[row], n1);
        std::cout << "\nresult:\n\n";
        printMatrix(A, m1, n1);
    } else if (strcmp(argv[1], "sort") == 0) {
        std::cout << "sortRow of matrix A" << std::endl;
        std::cout << "Enter number of rows: ";
        std::cin >> m1;
        std::cout << "Enter number of columns: ";
        std::cin >> n1;
        A = enterMatrix("A", m1, n1);
        std::cout << "Matrix: \n";
        printMatrix(A, m1, n1);
        sortRowsInMatrix(A, m1, n1);
        std::cout << "\nresult:\n\n";
        printMatrix(A, m1, n1);
    } else if (strcmp(argv[1], "help") == 0) {
        displayHelp();
    } else {
        displayHelp();
    }
    return 0;
}
